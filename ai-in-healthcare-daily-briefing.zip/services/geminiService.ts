import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { RawContentItem, ReportData } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

function parseJsonFromText(text: string): any {
    let jsonStr = text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
        jsonStr = match[2].trim();
    }
    try {
        return JSON.parse(jsonStr);
    } catch (e) {
        console.error("Failed to parse JSON response:", jsonStr);
        throw new Error("The AI returned a response that was not valid JSON.");
    }
}

export async function fetchContentFeed(topic: string, count: number, date: string | null): Promise<RawContentItem[]> {
    
    let promptCore = '';
    let dateForSnippet = date;

    switch (topic) {
        case 'Popular AI News (All Time)':
            promptCore = `Your sole function is to provide me with the most popular and influential news, discussions, and innovations related to "Artificial Intelligence" of all time. The date parameter should be ignored. Focus on landmark achievements, viral news, and highly-cited papers.`;
            dateForSnippet = new Date().toISOString().split('T')[0]; // Use today for items that have no date
            break;
        case 'Interesting AI Breakthroughs':
            promptCore = `Your sole function is to provide me with the most interesting, surprising, and recent breakthroughs related to "Artificial Intelligence". Focus on novel techniques, unexpected results, and creative applications. The provided date of ${date} should be treated as the anchor point for "recent".`;
            break;
        case 'AI in Healthcare':
        default:
            promptCore = `Your sole function is to provide me with the latest news, discussions, and innovations related to "AI in Healthcare" published strictly on this specific date: ${date}. Do not include content from any other date.`;
            break;
    }

    const prompt = `
      Act as an expert intelligence aggregator. ${promptCore}

      **CRITICAL SEARCH AND VERIFICATION INSTRUCTIONS:**
      You have access to Google Search. You MUST use it for an exhaustive search to perform the following actions:
      1.  **SEARCH AND VERIFY:** For each potential item, use Google Search to find the most authoritative and stable URL. If you find the story on a major, reputable source like **Nature.com, The Lancet, STAT News, major academic journals, or top-tier tech blogs**, you MUST prioritize that link.
      2.  **REPLACE BAD LINKS:** This search-and-verify step is crucial. Replace any unreliable, dead, or paywalled links with the better, authoritative ones you find.
      3.  **CORRECT DATA:** Use the authoritative source to verify and correct the 'source', 'author', and 'title' fields. Ensure the data is accurate.
      4.  **DISCARD IF NO LINK:** If you absolutely cannot find a valid, working, and publicly accessible link for an item even after searching, you may discard the item, but only as a last resort.

      GLOBAL SEARCH & TRANSLATION:
      1.  Search globally for content, including sources from all countries, especially India.
      2.  If any content (title, snippet) is not in English, you MUST translate it to English for the final JSON output.
      3.  Prioritize links that are globally accessible and do not require a VPN.

      SOURCE DIVERSITY:
      Your sources must be diverse: major news outlets (STAT, Fierce Healthcare), academic pre-prints (arXiv), professional social media (LinkedIn, Twitter/X), community discussions (Reddit), and influential blogs (a16z).

      ARTICLE COUNT:
      Your primary goal is to find exactly ${count} distinct items that meet the quality criteria. Make every effort to reach this number. If, after an exhaustive search, you genuinely cannot find ${count} items, return as many as you can find. It is crucial to be thorough.

      OUTPUT FORMAT:
      You MUST return the result as a single, clean, valid JSON array. Each object must have this structure: {"category": "...", "title": "...", "source": "...", "author": "...", "snippet": "...", "publishedDate": "${dateForSnippet}", "link": "https://..."}. Do not wrap it in any other text, explanation, or markdown fences.

      URL RULES:
      - The 'link' URL must be the full, raw, and exact URL.
      - ABSOLUTELY DO NOT modify, censor, shorten, or alter the URL. Do not use 'xxxxx'.
    `;

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: {
             tools: [{googleSearch: {}}],
        },
    });

    const parsedData = parseJsonFromText(response.text);

    if (!Array.isArray(parsedData)) {
        console.warn("AI response was not a JSON array, attempting to find an array within the response.", parsedData);
        if (typeof parsedData === 'object' && parsedData !== null) {
            const key = Object.keys(parsedData).find(k => Array.isArray(parsedData[k]));
            if (key) {
                return (parsedData[key] as Omit<RawContentItem, 'id'>[]).map((item, index) => ({
                    ...item,
                    id: `${Date.now()}-${index}`
                }));
            }
        }
        if (Array.isArray(parsedData?.articles)) {
            return parsedData.articles.map((item: Omit<RawContentItem, 'id'>, index: number) => ({
                ...item,
                id: `${Date.now()}-${index}`
            }));
        }
        
        if(Object.keys(parsedData).length > 0) {
             throw new Error("AI response was not a JSON array as expected.");
        }
        return [];
    }
    
    return parsedData.map((item: Omit<RawContentItem, 'id'>, index: number) => ({
        ...item,
        id: `${Date.now()}-${index}`
    }));
}

export async function generateSummaryReport(items: RawContentItem[], reportContentDate: string): Promise<ReportData> {
    const selectedItemsJson = JSON.stringify(items.map(({ id, ...rest }) => rest), null, 2);
    
    const prompt = `
      You are an expert editor creating a professional intelligence report. Based on the following selected articles (provided as a JSON array), generate a summary report.

      Selected Articles:
      ${selectedItemsJson}

      **CRITICAL SEARCH INSTRUCTIONS:**
      You have access to Google Search. You MUST use it to find a valid, working URL for each author's profile ('authorProfile').

      OUTPUT FORMAT:
      The final output MUST be a single, clean, valid JSON object with the following structure. Do not wrap it in any other text, explanation, or markdown fences.
      {
        "title": "Intelligence Report for Content from: ${reportContentDate}",
        "synopsis": "A 2-3 sentence summary of the key themes across the selected articles.",
        "items": [
          {
            "title": "[Title of the first article]",
            "summary": "A detailed paragraph summarizing the key points of the article.",
            "conclusion": "A 1-2 sentence analysis of the importance or implication of this development.",
            "author": "[Author's Name from the input data]",
            "sourceLink": "[The exact 'link' provided in the input data for this item]",
            "authorProfile": "[Use Google Search to find a working URL to the author's profile (e.g., LinkedIn, Twitter, official bio). If not found, use 'Profile not available']"
          }
        ]
      }
      
      URL RULES:
      1.  For 'sourceLink', use the exact, unmodified 'link' from the input data.
      2.  For 'authorProfile', return the full, raw, and exact URL you find.
      3.  ABSOLUTELY DO NOT modify, censor, shorten, or alter any URL. Do not use 'xxxxx'.
      4.  If a live author profile link cannot be found even with search, use the exact string 'Profile not available' for the 'authorProfile' field.
    `;

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: {
            tools: [{googleSearch: {}}],
        },
    });

    return parseJsonFromText(response.text);
}

export async function findBetterLink(title: string, author: string): Promise<string> {
    const prompt = `
      You are a highly skilled link verification expert. I have an article with a broken or poor-quality link. Your task is to find the single best, authoritative, and publicly accessible URL for this article.

      Article Title: "${title}"
      Article Author: "${author}"

      Use Google Search to find the correct, working link. Prioritize direct links to the article on major news sites, academic journals (like Nature.com, The Lancet), or the original source (like a company's official blog).

      CRITICAL: Your final response must be ONLY the raw URL string and nothing else. Do not add any explanation, commentary, or markdown. Just the URL.
    `;
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: {
            tools: [{googleSearch: {}}],
        },
    });

    // The response should be a plain text URL. Trim any whitespace.
    const newLink = response.text.trim();
    if (!newLink.startsWith('http')) {
        throw new Error("AI did not return a valid URL.");
    }
    return newLink;
}
