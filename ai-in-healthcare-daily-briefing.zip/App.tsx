import React, { useState, useCallback, useMemo, useEffect } from 'react';
import type { RawContentItem, ReportData, SavedReport } from './types';
import { fetchContentFeed, generateSummaryReport, findBetterLink } from './services/geminiService';
import { Header } from './components/Header';
import { ContentItem } from './components/ContentItem';
import { Report } from './components/Report';
import { Loader } from './components/Loader';
import { CalendarIcon, RefreshIcon, SparklesIcon } from './components/icons/Icons';
import { ReportHistory } from './components/ReportHistory';

const App: React.FC = () => {
  const [contentItems, setContentItems] = useState<RawContentItem[]>([]);
  const [selectedItemIds, setSelectedItemIds] = useState<Set<string>>(new Set());
  const [activeReport, setActiveReport] = useState<ReportData | null>(null);
  const [isLoadingFeed, setIsLoadingFeed] = useState(false);
  const [isLoadingReport, setIsLoadingReport] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [articleCount, setArticleCount] = useState<number>(10);
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [fetchCompleted, setFetchCompleted] = useState(false);
  const [savedReports, setSavedReports] = useState<SavedReport[]>([]);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [topic, setTopic] = useState('AI in Healthcare');
  const [fixingItemId, setFixingItemId] = useState<string | null>(null);

  const isDateRelevant = useMemo(() => topic !== 'Popular AI News (All Time)', [topic]);

  useEffect(() => {
    try {
      const storedReports = localStorage.getItem('savedReports');
      if (storedReports) {
        setSavedReports(JSON.parse(storedReports));
      }
    } catch (e) {
      console.error("Failed to parse saved reports from localStorage", e);
      setSavedReports([]);
    }
  }, []);
  
  useEffect(() => {
    try {
      localStorage.setItem('savedReports', JSON.stringify(savedReports));
    } catch (e) {
      console.error("Failed to save reports to localStorage", e);
    }
  }, [savedReports]);

  const usedItemLinks = useMemo(() => {
    const ids = new Set<string>();
    savedReports.forEach(saved => {
      saved.report.items.forEach(item => {
        ids.add(item.sourceLink);
      });
    });
    return ids;
  }, [savedReports]);

  const handleRefreshFeed = useCallback(async () => {
    setIsLoadingFeed(true);
    setError(null);
    setContentItems([]);
    setSelectedItemIds(new Set());
    setFetchCompleted(false);
    try {
      const dateToFetch = isDateRelevant ? selectedDate : null;
      const items = await fetchContentFeed(topic, articleCount, dateToFetch);
      setContentItems(items);
      setFetchCompleted(true);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'An unknown error occurred while fetching the feed.');
      setFetchCompleted(false);
    } finally {
      setIsLoadingFeed(false);
    }
  }, [topic, articleCount, selectedDate, isDateRelevant]);

  const handleSelectionChange = (itemLink: string) => {
    setSelectedItemIds(prev => {
      const newSelection = new Set(prev);
      if (newSelection.has(itemLink)) {
        newSelection.delete(itemLink);
      } else {
        newSelection.add(itemLink);
      }
      return newSelection;
    });
  };

  const handleSelectAll = () => {
    if (selectedItemIds.size === contentItems.length) {
      setSelectedItemIds(new Set());
    } else {
      const allLinks = new Set(contentItems.map(item => item.link));
      setSelectedItemIds(allLinks);
    }
  };
  
  const selectedItems = useMemo(() => {
    return contentItems.filter(item => selectedItemIds.has(item.link));
  }, [contentItems, selectedItemIds]);

  const allItemsSelected = contentItems.length > 0 && selectedItemIds.size === contentItems.length;

  const handleGenerateReport = useCallback(async () => {
    if (selectedItems.length === 0) return;
    setIsLoadingReport(true);
    setError(null);
    try {
      const reportDate = isDateRelevant ? selectedDate : 'All Time';
      const generatedReport = await generateSummaryReport(selectedItems, reportDate);
      const newSavedReport: SavedReport = {
        id: Date.now().toString(),
        generatedAt: new Date().toISOString(),
        report: generatedReport,
      };
      setSavedReports(prev => [newSavedReport, ...prev]);
      setActiveReport(generatedReport);
      setIsReportModalOpen(true);

    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'An unknown error occurred while generating the report.');
    } finally {
      setIsLoadingReport(false);
    }
  }, [selectedItems, savedReports, selectedDate, isDateRelevant]);

  const handleViewReport = (reportId: string) => {
    const reportToView = savedReports.find(r => r.id === reportId);
    if (reportToView) {
      setActiveReport(reportToView.report);
      setIsReportModalOpen(true);
    }
  };

  const handleDeleteReport = (reportId: string) => {
    if (window.confirm("Are you sure you want to delete this report? This cannot be undone.")) {
      setSavedReports(prev => prev.filter(r => r.id !== reportId));
    }
  };
  
  const handleCloseReport = () => {
    setIsReportModalOpen(false);
    setActiveReport(null);
  };
  
  const handleFixLink = async (itemId: string) => {
    setFixingItemId(itemId);
    const itemToFix = contentItems.find(item => item.id === itemId);
    if (!itemToFix) {
      setFixingItemId(null);
      return;
    }
    try {
      const newLink = await findBetterLink(itemToFix.title, itemToFix.author);
      setContentItems(prevItems => prevItems.map(item =>
        item.id === itemId ? { ...item, link: newLink } : item
      ));
    } catch (e) {
      console.error("Failed to fix link:", e);
      setError("Could not find a better link for this item. Please try again.");
    } finally {
      setFixingItemId(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8 max-w-4xl">
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}
        
        <div className="bg-white dark:bg-slate-800/50 rounded-xl shadow-lg p-6 mb-8 border border-slate-200 dark:border-slate-700">
          <h2 className="text-xl font-bold mb-2 text-slate-900 dark:text-white">Step 1: Your Content Feed</h2>
          <p className="text-slate-600 dark:text-slate-400 mb-4">Select a topic and other options, then click refresh.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col gap-2">
                <label htmlFor="topic-select" className="text-sm font-medium text-slate-700 dark:text-slate-300">Topic</label>
                <select 
                    id="topic-select"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    disabled={isLoadingFeed}
                    className="bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-1.5 px-2 text-sm focus:ring-indigo-500 focus:border-indigo-500 disabled:opacity-50"
                >
                    <option value="AI in Healthcare">AI in Healthcare</option>
                    <option value="Popular AI News (All Time)">Popular AI News (All Time)</option>
                    <option value="Interesting AI Breakthroughs">Interesting AI Breakthroughs</option>
                </select>
            </div>
             <div className="flex flex-col gap-2">
                <label htmlFor="article-count" className="text-sm font-medium text-slate-700 dark:text-slate-300">Articles</label>
                <select 
                    id="article-count"
                    value={articleCount}
                    onChange={(e) => setArticleCount(Number(e.target.value))}
                    disabled={isLoadingFeed}
                    className="bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-1.5 px-2 text-sm focus:ring-indigo-500 focus:border-indigo-500 disabled:opacity-50"
                >
                    <option value="10">10</option>
                    <option value="20">20</option>
                    <option value="30">30</option>
                    <option value="40">40</option>
                    <option value="50">50</option>
                </select>
            </div>
            <div className="flex flex-col gap-2">
                 <label htmlFor="article-date" className={`text-sm font-medium text-slate-700 dark:text-slate-300 ${!isDateRelevant ? 'text-slate-400 dark:text-slate-500' : ''}`}>Date</label>
                <div className="relative">
                    <div className={`absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none ${!isDateRelevant ? 'opacity-50' : ''}`}>
                        <CalendarIcon className="w-4 h-4 text-slate-400" />
                    </div>
                    <input
                        type="date"
                        id="article-date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        disabled={isLoadingFeed || !isDateRelevant}
                        className="bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-1.5 pl-9 pr-2 text-sm focus:ring-indigo-500 focus:border-indigo-500 disabled:opacity-50 w-full"
                    />
                </div>
            </div>
            <div className="flex flex-col justify-end">
                 <button
                  onClick={handleRefreshFeed}
                  disabled={isLoadingFeed}
                  className="flex items-center justify-center gap-2 px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:ring-opacity-75 disabled:bg-indigo-400 disabled:cursor-not-allowed transition-colors w-full"
                >
                  <RefreshIcon className={`w-5 h-5 ${isLoadingFeed ? 'animate-spin' : ''}`} />
                  {isLoadingFeed ? 'Refreshing...' : 'Refresh Feed'}
                </button>
            </div>
          </div>
           <p className="text-xs text-slate-500 dark:text-slate-400 mt-3">
            Note: The AI verifies source links. If a link is broken, try the ✨ button to find a better one.
          </p>
        </div>
        
        <ReportHistory reports={savedReports} onView={handleViewReport} onDelete={handleDeleteReport} />

        {fetchCompleted && !isLoadingFeed && (
          <div className="text-center my-4 p-3 bg-indigo-50 dark:bg-indigo-900/50 border border-indigo-200 dark:border-indigo-800 rounded-lg">
            <p className="font-semibold text-indigo-800 dark:text-indigo-200">
              Found {contentItems.length} article(s) for your query.
            </p>
          </div>
        )}

        {isLoadingFeed && <Loader text="Scouring the web for content..." />}
        
        {contentItems.length > 0 && (
          <>
            <div className="flex justify-end mb-4">
              <button
                onClick={handleSelectAll}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-lg shadow-sm hover:bg-slate-300 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-opacity-75 transition-colors"
              >
                {allItemsSelected ? 'Deselect All' : 'Select All'}
              </button>
            </div>

            <div className="space-y-4 mb-8">
              {contentItems.map(item => (
                <ContentItem
                  key={item.id}
                  item={item}
                  isSelected={selectedItemIds.has(item.link)}
                  isUsed={usedItemLinks.has(item.link)}
                  onSelectionChange={() => handleSelectionChange(item.link)}
                  onFixLink={() => handleFixLink(item.id)}
                  isFixing={fixingItemId === item.id}
                />
              ))}
            </div>

            <div className="bg-white dark:bg-slate-800/50 rounded-xl shadow-lg p-6 mb-8 border border-slate-200 dark:border-slate-700">
              <h2 className="text-xl font-bold mb-2 text-slate-900 dark:text-white">Step 2: Generate Your Summary</h2>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                You have selected {selectedItems.length} item(s). Click below to generate your intelligence report.
              </p>
              <button
                onClick={handleGenerateReport}
                disabled={selectedItems.length === 0 || isLoadingReport}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-opacity-75 disabled:bg-green-400 disabled:cursor-not-allowed transition-colors"
              >
                <SparklesIcon className="w-5 h-5" />
                {isLoadingReport ? 'Generating Report...' : 'Generate Summary Report'}
              </button>
            </div>
          </>
        )}
        
        {isLoadingReport && <Loader text="Synthesizing your intelligence report..." />}

        {isReportModalOpen && activeReport && (
          <Report reportData={activeReport} onClose={handleCloseReport} />
        )}

      </main>
      <footer className="text-center py-4 text-sm text-slate-500 dark:text-slate-400">
        <p>Powered by Gemini API</p>
      </footer>
    </div>
  );
};

export default App;