
import React from 'react';
import type { SavedReport } from '../types';
import { HistoryIcon, TrashIcon } from './icons/Icons';

interface ReportHistoryProps {
  reports: SavedReport[];
  onView: (id: string) => void;
  onDelete: (id: string) => void;
}

export const ReportHistory: React.FC<ReportHistoryProps> = ({ reports, onView, onDelete }) => {
  if (reports.length === 0) {
    return null;
  }

  return (
    <div className="bg-white dark:bg-slate-800/50 rounded-xl shadow-lg p-6 mb-8 border border-slate-200 dark:border-slate-700">
      <div className="flex items-center gap-3 mb-4">
        <HistoryIcon className="w-6 h-6 text-indigo-500" />
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Report History</h2>
      </div>
      {reports.length > 0 ? (
        <ul className="space-y-3">
          {reports.map((savedReport) => (
            <li
              key={savedReport.id}
              className="flex items-center justify-between gap-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg"
            >
              <div className="flex-grow">
                <p className="font-semibold text-slate-800 dark:text-slate-200 truncate" title={savedReport.report.title}>
                  {savedReport.report.title}
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Generated: {new Date(savedReport.generatedAt).toLocaleString()}
                </p>
              </div>
              <div className="flex-shrink-0 flex items-center gap-2">
                <button
                  onClick={() => onView(savedReport.id)}
                  className="px-3 py-1 text-sm font-semibold text-indigo-600 bg-indigo-100 dark:text-indigo-200 dark:bg-indigo-900/50 rounded-md hover:bg-indigo-200 dark:hover:bg-indigo-900"
                >
                  View
                </button>
                <button
                  onClick={() => onDelete(savedReport.id)}
                  aria-label={`Delete report: ${savedReport.report.title}`}
                  className="p-2 text-slate-500 dark:text-slate-400 hover:bg-red-100 dark:hover:bg-red-900/50 hover:text-red-600 dark:hover:text-red-400 rounded-full"
                >
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-slate-500 dark:text-slate-400">No reports generated yet. Select some articles and create one!</p>
      )}
    </div>
  );
};
