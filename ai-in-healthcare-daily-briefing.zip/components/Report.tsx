
import React from 'react';
import type { ReportData } from '../types';
import { DocxIcon, PdfIcon, CloseIcon } from './icons/Icons';
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx';
import saveAs from 'file-saver';
import jsPDF from 'jspdf';

interface ReportProps {
  reportData: ReportData;
  onClose: () => void;
}

const generateDocx = (report: ReportData) => {
    const doc = new Document({
        sections: [{
            children: [
                new Paragraph({
                    text: report.title,
                    heading: HeadingLevel.TITLE,
                }),
                new Paragraph({ text: "" }),
                new Paragraph({
                    children: [new TextRun({ text: "Synopsis", bold: true })],
                    heading: HeadingLevel.HEADING_2,
                }),
                new Paragraph({ text: report.synopsis }),
                new Paragraph({ text: "" }),
                ...report.items.flatMap((item, index) => [
                    new Paragraph({
                        text: `${index + 1}. ${item.title}`,
                        heading: HeadingLevel.HEADING_1,
                    }),
                    new Paragraph({ text: "" }),
                    new Paragraph({
                        children: [new TextRun({ text: "Summary", bold: true })],
                    }),
                    new Paragraph({ text: item.summary }),
                    new Paragraph({ text: "" }),
                    new Paragraph({
                        children: [new TextRun({ text: "Conclusion", bold: true })],
                    }),
                    new Paragraph({ text: item.conclusion }),
                    new Paragraph({ text: "" }),
                    new Paragraph({ children: [new TextRun({ text: `Author: ${item.author}`})] }),
                    new Paragraph({ children: [new TextRun({ text: `Source Link: ${item.sourceLink}`})] }),
                    new Paragraph({ children: [new TextRun({ text: `Author Profile: ${item.authorProfile}`})] }),
                    new Paragraph({ text: "" }),
                    ...(index < report.items.length - 1 ? [new Paragraph({text: "--------------------"})] : []),
                    new Paragraph({ text: "" }),
                ]),
            ],
        }],
    });
    
    Packer.toBlob(doc).then(blob => {
        saveAs(blob, "AI-in-Healthcare-Report.docx");
    });
};

const generatePdf = (report: ReportData) => {
    const doc = new jsPDF();
    const pageHeight = doc.internal.pageSize.height;
    let y = 20;
    const margin = 15;
    const maxWidth = doc.internal.pageSize.width - margin * 2;

    const checkY = (height: number) => {
        if (y + height > pageHeight - margin) {
            doc.addPage();
            y = margin;
        }
    };

    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    let titleLines = doc.splitTextToSize(report.title, maxWidth);
    checkY(titleLines.length * 8);
    doc.text(titleLines, margin, y);
    y += titleLines.length * 8;

    doc.setFontSize(14);
    y += 5;
    checkY(10);
    doc.text("Synopsis", margin, y);
    y += 7;
    
    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    let synopsisLines = doc.splitTextToSize(report.synopsis, maxWidth);
    checkY(synopsisLines.length * 5);
    doc.text(synopsisLines, margin, y);
    y += synopsisLines.length * 5 + 5;
    
    report.items.forEach((item, index) => {
        y+= 5;
        checkY(12);
        doc.setDrawColor(200, 200, 200);
        doc.line(margin, y, maxWidth + margin, y);
        y += 10;
        
        doc.setFont("helvetica", "bold");
        doc.setFontSize(16);
        let itemTitleLines = doc.splitTextToSize(`${index + 1}. ${item.title}`, maxWidth);
        checkY(itemTitleLines.length * 7);
        doc.text(itemTitleLines, margin, y);
        y += itemTitleLines.length * 7 + 5;

        doc.setFontSize(12);
        checkY(8);
        doc.text("Summary", margin, y);
        y += 6;
        
        doc.setFont("helvetica", "normal");
        doc.setFontSize(11);
        let summaryLines = doc.splitTextToSize(item.summary, maxWidth);
        checkY(summaryLines.length * 5);
        doc.text(summaryLines, margin, y);
        y += summaryLines.length * 5 + 5;
        
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        checkY(8);
        doc.text("Conclusion", margin, y);
        y += 6;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(11);
        let conclusionLines = doc.splitTextToSize(item.conclusion, maxWidth);
        checkY(conclusionLines.length * 5);
        doc.text(conclusionLines, margin, y);
        y += conclusionLines.length * 5 + 5;

        let details = `Author: ${item.author}\nSource Link: ${item.sourceLink}\nAuthor Profile: ${item.authorProfile}`;
        let detailsLines = doc.splitTextToSize(details, maxWidth);
        doc.setTextColor(150);
        checkY(detailsLines.length * 5);
        doc.text(detailsLines, margin, y);
        y += detailsLines.length * 5;
        doc.setTextColor(0);

    });
    
    doc.save('AI-in-Healthcare-Report.pdf');
};

const isValidUrl = (urlString: string) => {
    if (!urlString || typeof urlString !== 'string') return false;
    try {
        const url = new URL(urlString);
        return url.protocol === "http:" || url.protocol === "https:";
    } catch (_) {
        return false;
    }
};

export const Report: React.FC<ReportProps> = ({ reportData, onClose }) => {
  return (
    <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" 
        aria-modal="true" 
        role="dialog"
    >
        <div className="relative w-full max-w-4xl max-h-[90vh] bg-white dark:bg-slate-800 rounded-xl shadow-2xl flex flex-col">
            <div className="flex-shrink-0 p-6 border-b border-slate-200 dark:border-slate-700">
                <div className="flex justify-between items-start gap-4 flex-wrap">
                    <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex-1">{reportData.title}</h2>
                    <div className="flex items-center gap-2">
                        <button
                          onClick={() => generateDocx(reportData)}
                          className="flex items-center gap-2 px-3 py-1.5 bg-blue-500 text-white font-semibold rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition-colors"
                          aria-label="Download as DOCX"
                        >
                          <DocxIcon className="w-4 h-4" />
                          <span className="hidden sm:inline">.docx</span>
                        </button>
                        <button
                          onClick={() => generatePdf(reportData)}
                          className="flex items-center gap-2 px-3 py-1.5 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-75 transition-colors"
                           aria-label="Download as PDF"
                        >
                          <PdfIcon className="w-4 h-4" />
                           <span className="hidden sm:inline">.pdf</span>
                        </button>
                    </div>
                </div>
            </div>
            
            <div className="flex-grow p-6 md:p-8 overflow-y-auto">
              <div className="prose prose-slate dark:prose-invert max-w-none">
                <h3 className="text-lg font-semibold">Synopsis</h3>
                <p>{reportData.synopsis}</p>

                <hr className="my-6" />
                
                {reportData.items.map((item, index) => (
                  <div key={index} className="mb-8 last:mb-0">
                    <h4 className="font-bold text-xl">{index + 1}. {item.title}</h4>
                    
                    <h5 className="font-semibold mt-4">Summary</h5>
                    <p>{item.summary}</p>
                    
                    <h5 className="font-semibold mt-4">Conclusion</h5>
                    <p>{item.conclusion}</p>

                    <div className="mt-4 text-sm text-slate-500 dark:text-slate-400">
                        <p><strong>Author:</strong> {item.author}</p>
                        <p><strong>Source Link: </strong>
                            {isValidUrl(item.sourceLink) ? 
                                <a href={item.sourceLink} target="_blank" rel="noopener noreferrer" className="text-indigo-500 hover:underline break-all">{item.sourceLink}</a> 
                                : <span>{item.sourceLink}</span>
                            }
                        </p>
                        <p><strong>Author Profile: </strong>
                            {isValidUrl(item.authorProfile) ? 
                                <a href={item.authorProfile} target="_blank" rel="noopener noreferrer" className="text-indigo-500 hover:underline break-all">{item.authorProfile}</a> 
                                : <span>{item.authorProfile}</span>
                            }
                        </p>
                    </div>
                    {index < reportData.items.length - 1 && <hr className="my-6"/>}
                  </div>
                ))}
              </div>
            </div>
            
             <button
                onClick={onClose}
                className="absolute top-3 right-3 p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                aria-label="Close report view"
            >
                <CloseIcon className="w-6 h-6" />
            </button>
        </div>
    </div>
  );
};
