import React from 'react';
import type { RawContentItem } from '../types';
import { CalendarIcon, FixLinkIcon, RefreshIcon } from './icons/Icons';

interface ContentItemProps {
  item: RawContentItem;
  isSelected: boolean;
  isUsed: boolean;
  isFixing: boolean;
  onSelectionChange: (link: string) => void;
  onFixLink: (itemId: string) => void;
}

const categoryColors: { [key: string]: string } = {
  'News Article': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  'LinkedIn Post': 'bg-sky-100 text-sky-800 dark:bg-sky-900 dark:text-sky-300',
  'Academic Paper': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
  'Twitter (X) Thread': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
  'Reddit Discussion': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
  'Blog Post': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
};

export const ContentItem: React.FC<ContentItemProps> = ({ item, isSelected, isUsed, isFixing, onSelectionChange, onFixLink }) => {
  const handleCheckboxChange = () => {
    onSelectionChange(item.link);
  };
  
  const categoryClass = categoryColors[item.category] || 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300';

  return (
    <div className={`bg-white dark:bg-slate-800 rounded-lg shadow-md border transition-all duration-300 ${isSelected ? 'border-indigo-500 ring-2 ring-indigo-500' : 'border-slate-200 dark:border-slate-700'} ${isUsed ? 'opacity-60' : ''}`}>
      <div className="p-5 flex items-start gap-4">
        <div className="flex-shrink-0 pt-1">
          <input
            type="checkbox"
            checked={isSelected}
            onChange={handleCheckboxChange}
            className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
            aria-label={`Select item: ${item.title}`}
          />
        </div>
        <div className="flex-grow">
          <div className="flex items-center gap-3 mb-2 flex-wrap">
            <span className={`text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full ${categoryClass}`}>
              {item.category}
            </span>
             {item.publishedDate && (
                <span className="flex items-center text-sm text-slate-500 dark:text-slate-400">
                    <CalendarIcon className="w-4 h-4 mr-1.5" />
                    {item.publishedDate}
                </span>
            )}
            <span className="text-sm text-slate-500 dark:text-slate-400">{item.source}</span>
            {isUsed && (
              <span className="text-xs font-semibold text-green-800 bg-green-100 dark:text-green-200 dark:bg-green-900/50 px-2 py-0.5 rounded-full">
                Used in Report
              </span>
            )}
          </div>
          <div className="flex justify-between items-start gap-2">
            <a href={item.link} target="_blank" rel="noopener noreferrer" className="flex-grow hover:underline focus:outline-none focus:ring-2 focus:ring-indigo-300 rounded">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{item.title}</h3>
            </a>
            <button
                onClick={() => onFixLink(item.id)}
                disabled={isFixing}
                className="flex-shrink-0 p-1.5 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full disabled:cursor-not-allowed disabled:opacity-50"
                title="Find a better link for this article"
                aria-label="Fix link"
            >
                {isFixing ? <RefreshIcon className="w-5 h-5 animate-spin" /> : <FixLinkIcon className="w-5 h-5" />}
            </button>
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
            by <span className="font-semibold">{item.author}</span>
          </p>
          <p className="text-slate-700 dark:text-slate-300 prose prose-sm max-w-none">
            "{item.snippet}"
          </p>
        </div>
      </div>
    </div>
  );
};