
import React from 'react';
import { SparklesIcon } from './icons/Icons';

export const Header: React.FC = () => {
  return (
    <header className="bg-white/75 dark:bg-slate-900/75 backdrop-blur-lg sticky top-0 z-10 border-b border-slate-200 dark:border-slate-800">
      <div className="container mx-auto p-4 max-w-4xl">
        <div className="flex items-center gap-3">
          <SparklesIcon className="w-8 h-8 text-indigo-500" />
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            AI in Healthcare Daily Briefing
          </h1>
        </div>
      </div>
    </header>
  );
};
