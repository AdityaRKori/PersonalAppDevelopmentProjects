
export interface RawContentItem {
  id: string;
  category: string;
  title: string;
  source: string;
  author: string;
  snippet: string;
  link: string;
  publishedDate: string;
}

export interface ReportItem {
  title: string;
  summary: string;
  conclusion: string;
  author: string;
  sourceLink: string;
  authorProfile: string;
}

export interface ReportData {
  title: string;
  synopsis: string;
  items: ReportItem[];
}

export interface SavedReport {
  id: string;
  generatedAt: string;
  report: ReportData;
}
