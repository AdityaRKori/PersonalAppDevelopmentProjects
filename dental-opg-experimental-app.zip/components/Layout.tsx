
import React from 'react';
import Sidebar from './Sidebar';
import Header from './Header'; // Optional: if a header is desired

interface LayoutProps {
  children: React.ReactNode;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, onLogout }) => {
  return (
    <div className="flex h-screen bg-neutral-dark text-text-primary">
      <Sidebar onLogout={onLogout} />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Optional Header can go here */}
        {/* <Header />  */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-neutral-dark p-6 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
    