
export const APP_NAME = "Dental OPG Experimental App";
export const GEMINI_API_KEY_ENV_VAR = "API_KEY"; // As per instructions

export const MODELS = {
  text: "gemini-2.5-flash-preview-04-17",
  image: "imagen-3.0-generate-002",
};

export const DEFAULT_PATIENT_IMAGE_PLACEHOLDER = "https://picsum.photos/800/400?grayscale";