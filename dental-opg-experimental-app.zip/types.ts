
export interface Patient {
  id: string;
  name: string;
  dob: string; // Date of Birth, format YYYY-MM-DD
  patientId: string; // Custom Patient ID
  opgImageUrl?: string; // URL or path to the OPG image
  lastUploadDate?: string; // ISO date string
  notes?: string;
}

export enum ModalView {
  NONE,
  NEW_PATIENT,
  UPLOAD_OPG,
}

export interface DentalAnalysisResponse {
  dentalFormula: string;
  findings: string[];
  diagnosisSummary: string;
  recommendedNextSteps: string[];
}
