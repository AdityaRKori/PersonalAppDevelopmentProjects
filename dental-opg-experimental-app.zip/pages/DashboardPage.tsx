
import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Patient } from '../types'; // Assuming some dummy data might be summarized

// SVG Icons
const UsersIconSolid = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-8 h-8"><path d="M10 8a3 3 0 100-6 3 3 0 000 6zM3.465 14.493a1.23 1.23 0 00.41 1.412A9.957 9.957 0 0010 18c2.31 0 4.438-.784 6.131-2.1.43-.333.604-.903.408-1.41a7.002 7.002 0 00-13.074.003z" /></svg>;
const DocumentChartBarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-8 h-8"><path fillRule="evenodd" d="M15.98 1.423A.75.75 0 0116.5 2.105v12.112a.75.75 0 01-1.107.659L12 13.295l-3.393 1.582a.75.75 0 01-1.107-.66V2.105a.75.75 0 01.52-.71A9.006 9.006 0 0110 1c1.458 0 2.844.349 4.02.973.18.09.358.19.52.29.162.1.314.212.44.33zm1.168 13.91a.75.75 0 00-1.022-.248A7.502 7.502 0 0010 13.5a7.502 7.502 0 00-6.126 1.585.75.75 0 10.774 1.28A5.996 5.996 0 0110 15a5.996 5.996 0 014.862 1.09.75.75 0 001.286-.773z" clipRule="evenodd" /></svg>;
const PlusCircleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.75-11.25a.75.75 0 00-1.5 0v2.5h-2.5a.75.75 0 000 1.5h2.5v2.5a.75.75 0 001.5 0v-2.5h2.5a.75.75 0 000-1.5h-2.5v-2.5z" clipRule="evenodd" /></svg>;
const ArrowUpTrayIcon = () => <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path d="M9.25 8.006V2.75a.75.75 0 011.5 0v5.256l1.97-1.97a.75.75 0 111.06 1.06L10.53 11.28a.75.75 0 01-1.06 0L6.22 8.126a.75.75 0 111.06-1.06l1.97 1.97z" /><path d="M3.5 12.75a.75.75 0 00-1.5 0v2.5A2.75 2.75 0 004.75 18h10.5A2.75 2.75 0 0018 15.25v-2.5a.75.75 0 00-1.5 0v2.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25v-2.5z" /></svg>;


// Dummy data for summary
const summaryData = {
  totalPatients: 125, // Replace with actual data fetching
  recentUploads: 12,  // Replace with actual data fetching
};

const DashboardPage: React.FC = () => {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-semibold text-text-primary">Welcome Back, Doctor!</h1>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-neutral-light p-6 rounded-lg shadow-lg flex items-center space-x-4">
          <div className="p-3 bg-primary rounded-full">
            <UsersIconSolid />
          </div>
          <div>
            <p className="text-sm text-text-secondary">Total Patients</p>
            <p className="text-2xl font-bold text-text-primary">{summaryData.totalPatients}</p>
          </div>
        </div>
        <div className="bg-neutral-light p-6 rounded-lg shadow-lg flex items-center space-x-4">
          <div className="p-3 bg-secondary rounded-full">
            <DocumentChartBarIcon />
          </div>
          <div>
            <p className="text-sm text-text-secondary">Recent OPG Uploads (7 days)</p>
            <p className="text-2xl font-bold text-text-primary">{summaryData.recentUploads}</p>
          </div>
        </div>
         {/* Add more summary cards as needed */}
      </div>

      {/* Quick Actions */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-text-primary">Quick Actions</h2>
        <div className="flex flex-wrap gap-4">
          <Link to="/patients?action=new">
            <Button variant="primary" leftIcon={<PlusCircleIcon />}>Add New Patient</Button>
          </Link>
          <Link to="/upload">
            <Button variant="secondary" leftIcon={<ArrowUpTrayIcon />}>Upload OPG</Button>
          </Link>
        </div>
      </div>

      {/* Placeholder for Recent Activity or Upcoming Appointments */}
      <div className="bg-neutral-light p-6 rounded-lg shadow-lg">
        <h2 className="text-xl font-semibold text-text-primary mb-4">Recent Activity</h2>
        <p className="text-text-secondary">
          No recent activity to display. This section can show recently viewed patients,
          uploaded images, or critical alerts in the future.
        </p>
        {/* Example list items (replace with dynamic data) */}
        <ul className="mt-4 space-y-2">
            <li className="p-2 border-b border-neutral-DEFAULT text-sm">Viewed Patient: John Doe - OPG_JD_20240115.dcm</li>
            <li className="p-2 border-b border-neutral-DEFAULT text-sm">Uploaded Image for: Jane Smith - OPG_JS_20240114.dcm</li>
        </ul>
      </div>
    </div>
  );
};

export default DashboardPage;
    