
import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';
// import Input from '../components/Input'; // Input for patient selection is still relevant
import { Patient } from '../types'; 

// Mock patient data for selection
const mockPatients: Patient[] = [
  { id: '1', name: 'John Doe', patientId: 'P001', dob: '1980-01-01' },
  { id: '2', name: 'Jane Smith', patientId: 'P002', dob: '1990-02-02' },
];

const UploadIconLarge = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto text-gray-400 mb-4"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" /></svg>;
const FileIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 mr-2 text-primary"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>;
const AnalyzeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l3-3m0 0l3 3m-3-3v6m4.846-6.401a8.966 8.966 0 0111.496 9.123 8.966 8.966 0 01-18.213-3.612 3.75 3.75 0 013.75-3.75h1.033M16.5 19.5L21 15m0 0l-4.5-4.5M21 15H9" /></svg>


const UploadPage: React.FC = () => {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [file, setFile] = useState<File | null>(null);
  const [uploadedFileContent, setUploadedFileContent] = useState<{ base64Data: string; mimeType: string; name: string } | null>(null);
  const [fileReadError, setFileReadError] = useState<string | null>(null);
  const navigate = useNavigate();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const currentFile = acceptedFiles[0];
      setFile(currentFile);
      setFileReadError(null);
      setUploadedFileContent(null); // Reset previous content

      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === 'string') {
          const base64Full = event.target.result; // "data:image/png;base64,xxxxxxxx"
          const base64Data = base64Full.split(',')[1];
          setUploadedFileContent({ base64Data, mimeType: currentFile.type, name: currentFile.name });
        } else {
          setFileReadError('Failed to read file content.');
        }
      };
      reader.onerror = () => {
        setFileReadError(`Error reading file: ${currentFile.name}.`);
        setUploadedFileContent(null);
      };
      reader.readAsDataURL(currentFile);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/dicom': ['.dcm'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png']
    },
    multiple: false,
  });

  const handleAnalyzeImage = () => {
    if (!uploadedFileContent) {
      alert('File content is not available. Please re-select the file.');
      return;
    }
    if (!selectedPatientId) {
        alert('Please select a patient to associate with this analysis.');
        return;
    }

    navigate(
        `/patients/${selectedPatientId}/viewer`, 
        { 
            state: { 
                uploadedImageData: uploadedFileContent.base64Data,
                uploadedMimeType: uploadedFileContent.mimeType,
                uploadedFileName: uploadedFileContent.name,
            }
        }
    );
  };

  const removeFile = () => {
    setFile(null);
    setUploadedFileContent(null);
    setFileReadError(null);
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8 p-4">
      <h1 className="text-3xl font-semibold text-text-primary text-center">Upload OPG for Analysis</h1>

      <div className="bg-neutral-light p-6 rounded-lg shadow-lg">
        <label htmlFor="patient-select" className="block text-sm font-medium text-text-secondary mb-1">
          1. Select Patient for this OPG
        </label>
        <select
          id="patient-select"
          value={selectedPatientId}
          onChange={(e) => setSelectedPatientId(e.target.value)}
          className="w-full px-3 py-2 bg-neutral-DEFAULT border border-neutral-light rounded-md shadow-sm 
                     focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-text-primary"
        >
          <option value="" disabled>-- Select a Patient --</option>
          {mockPatients.map(p => (
            <option key={p.id} value={p.id}>{p.name} (ID: {p.patientId})</option>
          ))}
        </select>
      </div>

      <div className="bg-neutral-light p-6 rounded-lg shadow-lg">
        <label className="block text-sm font-medium text-text-secondary mb-1">
            2. Choose OPG Image File
        </label>
        <div 
            {...getRootProps()} 
            className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors
                        ${isDragActive ? 'border-primary bg-primary bg-opacity-10' : 'border-neutral-DEFAULT hover:border-gray-500'}
                        bg-neutral-DEFAULT`}
        >
            <input {...getInputProps()} />
            <UploadIconLarge />
            {isDragActive ? (
            <p className="text-primary font-semibold">Drop the image file here ...</p>
            ) : (
            <p className="text-text-secondary">Drag 'n' drop an image file here, or click to select</p>
            )}
            <p className="text-xs text-gray-500 mt-1">Supports .dcm, .jpg, .png, .jpeg (Max 1 file)</p>
        </div>
      </div>
      

      {fileReadError && (
        <p className="text-red-500 font-semibold text-center">{fileReadError}</p>
      )}

      {file && uploadedFileContent && (
        <div className="bg-neutral-light p-4 rounded-lg shadow space-y-3">
          <h3 className="font-semibold text-text-primary">Selected File:</h3>
            <div className="flex items-center justify-between p-2 bg-neutral-DEFAULT rounded">
              <div className="flex items-center">
                <FileIcon />
                <span className="text-sm text-text-primary ml-2">{file.name} ({(file.size / 1024).toFixed(2)} KB)</span>
              </div>
              <Button variant="danger" size="sm" onClick={removeFile}>
                Remove
              </Button>
            </div>
            <Button 
                onClick={handleAnalyzeImage} 
                disabled={!selectedPatientId || !uploadedFileContent}
                className="w-full"
                variant="primary"
                size="lg"
                leftIcon={<AnalyzeIcon />}
            >
                Proceed to Analyze This Image
            </Button>
            {!selectedPatientId && <p className="text-xs text-amber-400 text-center mt-1">Please select a patient to enable analysis.</p>}
        </div>
      )}
    </div>
  );
};

export default UploadPage;
