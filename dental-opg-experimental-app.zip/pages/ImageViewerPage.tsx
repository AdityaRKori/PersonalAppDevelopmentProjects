import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { Patient, DentalAnalysisResponse } from '../types';
import Button from '../components/Button';
import { DEFAULT_PATIENT_IMAGE_PLACEHOLDER } from '../constants';
import { analyzeOpgImage } from '../services/geminiService';

// Mock patient data fetching (replace with actual API call)
const fetchPatientById = async (id: string): Promise<Patient | undefined> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  const mockPatients: Patient[] = [
    { id: '1', name: 'John Doe', dob: '1985-07-15', patientId: 'P001', opgImageUrl: 'https://picsum.photos/seed/patient1/1200/600?grayscale&random=1', notes: 'Previously traced IAN on lower left.' },
    { id: '2', name: 'Jane Smith', dob: '1992-03-22', patientId: 'P002', opgImageUrl: 'https://picsum.photos/seed/patient2/1200/600?grayscale&random=2' },
  ];
  return mockPatients.find(p => p.id === id);
};

// Icons
const BrightnessIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-6.364-.386l1.591-1.591M3 12h2.25m.386-6.364l1.591 1.591M12 8.25A4.502 4.502 0 0116.5 12.75c0 1.33-.527 2.553-1.39 3.483-.18.18-.372.348-.576.504A4.505 4.505 0 017.5 12.75c0-1.33.527 2.553 1.39-3.483.18-.18.372.348-.576-.504A4.505 4.505 0 0112 8.25z" /></svg>;
const ContrastIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3v18m4.5-4.5H7.5" /></svg>;
const InvertIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" /></svg>;
const ZoomInIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607zM10.5 7.5v6m3-3h-6" /></svg>;
const ZoomOutIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607zM13.5 10.5h-6" /></svg>;
const PanIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" /></svg>;
const SparklesIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2"><path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12L17 14.25l-1.25-2.25L13.5 11l2.25-1.25L17 7.5l1.25 2.25L20.5 11l-2.25 1.25z" /></svg>;

interface UploadedImageState {
    base64Data: string;
    mimeType: string;
    fileName: string;
    dataUrl: string;
}

const CORS_FALLBACK_IMAGE_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";

// Utility function to convert image URL to base64
async function imageUrlToBase64(url: string): Promise<{ base64Data: string, mimeType: string }> {
  try {
    // Attempt to mitigate potential CORS issues with picsum.photos by adding a timestamp
    const anUrl = new URL(url);
    if (url.includes("picsum.photos")) {
        anUrl.searchParams.append("timestamp", Date.now().toString());
    }
    
    const response = await fetch(anUrl.toString(), { mode: 'cors' }); // 'cors' mode is default but explicit
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status} for URL ${url}`);
    }
    const blob = await response.blob();
    const mimeType = blob.type;
    if (!mimeType.startsWith('image/')) {
        console.warn(`Fetched content from ${url} is not an image: ${mimeType}. Using placeholder.`);
        return {
            base64Data: CORS_FALLBACK_IMAGE_BASE64, 
            mimeType: "image/png"
        };
    }
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          resolve({ base64Data: reader.result.split(',')[1], mimeType });
        } else {
          reject(new Error('Failed to read file as base64 string.'));
        }
      };
      reader.onerror = (error) => reject(new Error(`FileReader error: ${error}`));
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.error("Error converting image URL to base64:", error);
    console.warn("Using placeholder base64 image due to conversion error. AI analysis quality may be affected.");
    return {
        base64Data: CORS_FALLBACK_IMAGE_BASE64,
        mimeType: "image/png"
    };
  }
}


const ImageViewerPage: React.FC = () => {
  const { patientId } = useParams<{ patientId: string }>();
  const navigate = useNavigate();
  const location = useLocation();

  const [patient, setPatient] = useState<Patient | null>(null);
  const [uploadedImage, setUploadedImage] = useState<UploadedImageState | null>(null);
  const [loadingPatient, setLoadingPatient] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [isInverted, setIsInverted] = useState(false);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<DentalAnalysisResponse | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  useEffect(() => {
    if (location.state?.uploadedImageData && location.state?.uploadedMimeType && location.state?.uploadedFileName) {
      const { uploadedImageData, uploadedMimeType, uploadedFileName } = location.state as { uploadedImageData: string; uploadedMimeType: string; uploadedFileName: string };
      setUploadedImage({
        base64Data: uploadedImageData,
        mimeType: uploadedMimeType,
        fileName: uploadedFileName,
        dataUrl: `data:${uploadedMimeType};base64,${uploadedImageData}`
      });
       window.history.replaceState({}, document.title)
    }
  }, [location.state]);

  useEffect(() => {
    if (!patientId) {
      if (!uploadedImage) setError("Patient ID is missing and no uploaded image found.");
      setLoadingPatient(false);
      return;
    }

    const loadPatientData = async () => {
      setLoadingPatient(true);
      setError(null);
      if (!uploadedImage) {
        setAnalysisResult(null); 
        setAnalysisError(null);
      }
      try {
        const fetchedPatient = await fetchPatientById(patientId);
        if (fetchedPatient) {
          setPatient(fetchedPatient);
        } else {
          setError("Patient not found.");
        }
      } catch (err) {
        setError("Failed to load patient data.");
        console.error(err);
      } finally {
        setLoadingPatient(false);
      }
    };
    loadPatientData();
  }, [patientId, uploadedImage]); 

  const handleRunAnalysis = useCallback(async () => {
    setIsAnalyzing(true);
    setAnalysisError(null);
    setAnalysisResult(null);

    try {
      let base64DataForAnalysis: string | undefined;
      let mimeTypeForAnalysis: string | undefined;

      if (uploadedImage) {
        base64DataForAnalysis = uploadedImage.base64Data;
        mimeTypeForAnalysis = uploadedImage.mimeType;
      } else if (patient?.opgImageUrl) {
        const { base64Data, mimeType } = await imageUrlToBase64(patient.opgImageUrl);
        base64DataForAnalysis = base64Data;
        mimeTypeForAnalysis = mimeType;

        if (base64DataForAnalysis === CORS_FALLBACK_IMAGE_BASE64) {
          throw new Error("Cannot analyze default image: The patient's default OPG image could not be loaded (possibly due to network or security restrictions). Please upload an image directly for analysis.");
        }
      }

      if (!base64DataForAnalysis || !mimeTypeForAnalysis) {
        throw new Error("No image data available for analysis. Please upload an image or ensure the patient has a valid OPG.");
      }
      
      const result = await analyzeOpgImage(base64DataForAnalysis, mimeTypeForAnalysis);
      setAnalysisResult(result);
    } catch (err: any) {
      console.error("AI Analysis failed:", err);
      let errorMessage = err.message || "An error occurred during AI analysis.";
      if (errorMessage.toLowerCase().includes("api key not configured")) {
        errorMessage = "AI Analysis Failed: Gemini API key is not configured. Please ensure the API_KEY environment variable is set correctly and the application is rebuilt/restarted if necessary.";
      }
      setAnalysisError(errorMessage);
    } finally {
      setIsAnalyzing(false);
    }
  }, [patient, uploadedImage]);


  if (loadingPatient && !uploadedImage) { 
    return <div className="flex justify-center items-center h-full text-text-primary">Loading patient data...</div>;
  }

  if (error && !uploadedImage) { 
    return <div className="flex flex-col justify-center items-center h-full text-red-500">
        <p>{error}</p>
        <Button onClick={() => navigate('/patients')} variant="primary" className="mt-4">Back to Patients</Button>
    </div>;
  }

  if (!patient && !uploadedImage) { 
    return <div className="flex justify-center items-center h-full text-text-primary">Patient data not available and no image uploaded.</div>;
  }
  
  const imageSrcToDisplay = uploadedImage?.dataUrl || patient?.opgImageUrl || DEFAULT_PATIENT_IMAGE_PLACEHOLDER;
  const imageAltText = uploadedImage?.fileName ? `Uploaded: ${uploadedImage.fileName}` : (patient ? `OPG for ${patient.name}` : "OPG Image");
  
  let pageTitle = "OPG Viewer";
  if (uploadedImage) {
    pageTitle = patient ? `Analyze Upload: ${uploadedImage.fileName} (Patient: ${patient.name})` : `Analyze Upload: ${uploadedImage.fileName}`;
  } else if (patient) {
    pageTitle = `OPG Viewer: ${patient.name}`;
  }


  return (
    <div className="flex flex-col h-full bg-neutral-darker">
      <div className="p-3 bg-neutral-dark shadow-md flex justify-between items-center">
        <div>
            <h1 className="text-xl font-semibold text-text-primary">{pageTitle}</h1>
            {patient && <p className="text-sm text-text-secondary">Patient ID: {patient.patientId} | DOB: {new Date(patient.dob).toLocaleDateString()}</p>}
        </div>
        <Button onClick={() => navigate('/patients')} variant="outline" size="sm">Back to Patient List</Button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div className="w-20 bg-neutral-dark p-3 flex flex-col items-center space-y-3 border-r border-neutral-light">
          <Button variant="outline" title="Zoom In" className="w-full aspect-square flex items-center justify-center p-0"><ZoomInIcon /></Button>
          <Button variant="outline" title="Zoom Out" className="w-full aspect-square flex items-center justify-center p-0"><ZoomOutIcon /></Button>
          <Button variant="outline" title="Pan" className="w-full aspect-square flex items-center justify-center p-0"><PanIcon /></Button>
          <div className="w-full pt-2 border-t border-neutral-light"></div>
          <Button variant="outline" title="Brightness" className="w-full aspect-square flex items-center justify-center p-0"><BrightnessIcon /></Button>
          <input type="range" min="50" max="150" value={brightness} onChange={(e) => setBrightness(Number(e.target.value))} className="w-full h-1.5 accent-primary cursor-pointer mt-1" />
          <Button variant="outline" title="Contrast" className="w-full aspect-square flex items-center justify-center p-0"><ContrastIcon /></Button>
          <input type="range" min="50" max="150" value={contrast} onChange={(e) => setContrast(Number(e.target.value))} className="w-full h-1.5 accent-primary cursor-pointer mt-1" />
          <Button variant="outline" title="Invert Colors" onClick={() => setIsInverted(!isInverted)} className={`w-full aspect-square flex items-center justify-center p-0 ${isInverted ? 'bg-primary text-white' : ''}`}><InvertIcon /></Button>
        </div>

        <div className="flex-1 bg-black flex items-center justify-center p-2 overflow-hidden">
           <div id="image-viewport" className="w-full h-full relative" style={{ filter: `brightness(${brightness}%) contrast(${contrast}%) ${isInverted ? 'invert(1)' : ''}`}}>
            <img src={imageSrcToDisplay} alt={imageAltText} className="max-w-full max-h-full object-contain" />
            {!uploadedImage && (
                <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white text-xs p-1 rounded">
                    Cornerstone.js integration placeholder (Displaying patient's default OPG)
                </div>
            )}
             {uploadedImage && (
                <div className="absolute top-2 left-2 bg-black bg-opacity-50 text-white text-xs p-1 rounded">
                    Displaying uploaded image: {uploadedImage.fileName}
                </div>
            )}
          </div>
        </div>
        
        <div className="w-72 bg-neutral-dark p-4 border-l border-neutral-light overflow-y-auto space-y-4">
            <div>
                <h3 className="text-md font-semibold text-text-primary mb-2">Patient Notes</h3>
                <textarea 
                    className="w-full h-24 p-2 bg-neutral-light border border-neutral-DEFAULT rounded-md text-sm text-text-primary focus:ring-primary focus:border-primary"
                    defaultValue={patient?.notes || ''}
                    placeholder="Add notes here..."
                    disabled={!patient}
                />
                <Button variant="primary" size="sm" className="mt-2 w-full" disabled={!patient}>Save Notes</Button>
            </div>
            
            <div className="pt-4 border-t border-neutral-DEFAULT">
                <h3 className="text-md font-semibold text-text-primary mb-2">AI Dental Analysis</h3>
                {!isAnalyzing && !analysisResult && !analysisError && (
                    <Button 
                        onClick={handleRunAnalysis} 
                        variant="secondary" 
                        className="w-full" 
                        leftIcon={<SparklesIcon/>}
                        disabled={!imageSrcToDisplay || imageSrcToDisplay === DEFAULT_PATIENT_IMAGE_PLACEHOLDER}
                    >
                        Run AI Analysis
                    </Button>
                )}
                {isAnalyzing && (
                    <div className="text-sm text-text-secondary flex items-center justify-center py-4">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Analyzing image, please wait...
                    </div>
                )}
                {analysisError && !isAnalyzing && (
                    <div className={`p-3 rounded text-sm ${analysisError.includes("API key") ? 'bg-orange-900 bg-opacity-70 border border-orange-700 text-orange-200' : 'bg-red-900 bg-opacity-50 border border-red-700 text-red-300'}`}>
                        <p className="font-semibold">
                            {analysisError.includes("API key") ? "Configuration Issue:" : "Analysis Failed:"}
                        </p>
                        <p>{analysisError}</p>
                        {!analysisError.includes("Cannot analyze default image") && (
                             <Button 
                                onClick={handleRunAnalysis} 
                                variant={analysisError.includes("API key") ? "outline" : "danger"} 
                                size="sm" 
                                className="mt-2"
                            >
                                Try Again
                            </Button>
                        )}
                        {analysisError.includes("Cannot analyze default image") && (
                             <Button 
                                onClick={() => navigate('/upload')}
                                variant="primary" 
                                size="sm" 
                                className="mt-2"
                            >
                                Upload Image
                            </Button>
                        )}
                    </div>
                )}
                {analysisResult && !isAnalyzing && (
                    <div className="space-y-3 text-sm">
                        <div>
                            <p className="font-semibold text-text-secondary">Dental Formula:</p>
                            <p className="text-text-primary bg-neutral-light p-2 rounded text-xs whitespace-pre-wrap">{analysisResult.dentalFormula}</p>
                        </div>
                        <div>
                            <p className="font-semibold text-text-secondary">Findings:</p>
                            <ul className="list-disc list-inside pl-1 space-y-1 text-text-primary bg-neutral-light p-2 rounded text-xs">
                                {analysisResult.findings.map((item, index) => <li key={index}>{item}</li>)}
                            </ul>
                        </div>
                        <div>
                            <p className="font-semibold text-text-secondary">Diagnosis Summary:</p>
                            <p className="text-text-primary bg-neutral-light p-2 rounded text-xs whitespace-pre-wrap">{analysisResult.diagnosisSummary}</p>
                        </div>
                        <div>
                            <p className="font-semibold text-text-secondary">Recommended Next Steps:</p>
                            <ul className="list-disc list-inside pl-1 space-y-1 text-text-primary bg-neutral-light p-2 rounded text-xs">
                                {analysisResult.recommendedNextSteps.map((item, index) => <li key={index}>{item}</li>)}
                            </ul>
                        </div>
                         <Button onClick={handleRunAnalysis} variant="outline" size="sm" className="mt-2 w-full">Re-run Analysis</Button>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ImageViewerPage;
