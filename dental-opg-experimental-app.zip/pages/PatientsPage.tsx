
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Patient, ModalView } from '../types';
import Button from '../components/Button';
import Input from '../components/Input';
import Modal from '../components/Modal';

// Icons
const PlusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>;
const EyeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const EditIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" /></svg>;


// Mock patient data
const initialPatients: Patient[] = [
  { id: '1', name: 'John Doe', dob: '1985-07-15', patientId: 'P001', lastUploadDate: '2024-07-20T10:00:00Z', opgImageUrl: 'https://picsum.photos/seed/patient1/200/100' },
  { id: '2', name: 'Jane Smith', dob: '1992-03-22', patientId: 'P002', lastUploadDate: '2024-07-18T14:30:00Z', opgImageUrl: 'https://picsum.photos/seed/patient2/200/100' },
  { id: '3', name: 'Robert Johnson', dob: '1978-11-02', patientId: 'P003', lastUploadDate: '2024-07-19T09:15:00Z' },
  { id: '4', name: 'Emily White', dob: '2001-01-30', patientId: 'P004' },
];

const NewPatientForm: React.FC<{ onSave: (patient: Patient) => void; onClose: () => void }> = ({ onSave, onClose }) => {
  const [name, setName] = useState('');
  const [dob, setDob] = useState('');
  const [patientId, setPatientId] = useState('');
  // Add more fields as needed

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Basic validation
    if (!name || !dob || !patientId) {
      alert('Please fill all required fields.');
      return;
    }
    const newPatient: Patient = {
      id: String(Date.now()), // Simple unique ID for mock
      name,
      dob,
      patientId,
      lastUploadDate: new Date().toISOString(),
    };
    onSave(newPatient);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input label="Full Name" value={name} onChange={(e) => setName(e.target.value)} required />
      <Input label="Date of Birth" type="date" value={dob} onChange={(e) => setDob(e.target.value)} required />
      <Input label="Patient ID" value={patientId} onChange={(e) => setPatientId(e.target.value)} required />
      {/* Add more form fields here */}
      <div className="flex justify-end space-x-3 mt-6">
        <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
        <Button type="submit" variant="primary">Save Patient</Button>
      </div>
    </form>
  );
};


const PatientsPage: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>(initialPatients);
  const [searchTerm, setSearchTerm] = useState('');
  const [modalView, setModalView] = useState<ModalView>(ModalView.NONE);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('action') === 'new') {
      setEditingPatient(null); // Clear any previous edit state
      setModalView(ModalView.NEW_PATIENT);
      // Clean up URL: remove action=new query param
      navigate(location.pathname, { replace: true });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, navigate]);


  const handleAddNewPatient = () => {
    setEditingPatient(null);
    setModalView(ModalView.NEW_PATIENT);
  };
  
  const handleEditPatient = (patient: Patient) => {
    setEditingPatient(patient);
    setModalView(ModalView.NEW_PATIENT); // Reuse the same form for editing
  };

  const handleSavePatient = (patientData: Patient) => {
    if (editingPatient) { // Editing existing patient
      setPatients(patients.map(p => p.id === editingPatient.id ? {...editingPatient, ...patientData, id: editingPatient.id} : p));
    } else { // Adding new patient
       setPatients([patientData, ...patients]);
    }
    setModalView(ModalView.NONE);
    setEditingPatient(null);
  };

  const filteredPatients = patients.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.patientId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (e) {
      return dateString; // if it's already formatted or invalid
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold text-text-primary">Patient Management</h1>
        <Button onClick={handleAddNewPatient} variant="primary" leftIcon={<PlusIcon />}>
          Add New Patient
        </Button>
      </div>

      <Input
        type="text"
        placeholder="Search patients by name or ID..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="max-w-md"
      />

      <div className="bg-neutral-light shadow-lg rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-DEFAULT">
            <thead className="bg-neutral-DEFAULT">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">DOB</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Patient ID</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Last Upload</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-neutral-light divide-y divide-neutral-DEFAULT">
              {filteredPatients.map((patient) => (
                <tr key={patient.id} className="hover:bg-neutral-DEFAULT transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-text-primary">{patient.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{formatDate(patient.dob)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{patient.patientId}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{patient.lastUploadDate ? formatDate(patient.lastUploadDate) : 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    {patient.opgImageUrl && (
                       <Button variant="outline" size="sm" onClick={() => navigate(`/patients/${patient.id}/viewer`)} leftIcon={<EyeIcon />}>View OPG</Button>
                    )}
                     <Button variant="outline" size="sm" onClick={() => handleEditPatient(patient)} leftIcon={<EditIcon />}>Edit</Button>
                  </td>
                </tr>
              ))}
              {filteredPatients.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-sm text-text-secondary">
                    No patients found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      <Modal
        isOpen={modalView === ModalView.NEW_PATIENT}
        onClose={() => { setModalView(ModalView.NONE); setEditingPatient(null); }}
        title={editingPatient ? "Edit Patient" : "Add New Patient"}
      >
        <NewPatientForm 
          onSave={handleSavePatient} 
          onClose={() => { setModalView(ModalView.NONE); setEditingPatient(null); }} 
          // key is important to reset form state when switching between add/edit or editing different patients
          key={editingPatient ? editingPatient.id : 'new-patient-form'}
          // initialData={editingPatient} // You'd need to modify NewPatientForm to accept initialData
        />
      </Modal>
    </div>
  );
};

export default PatientsPage;
    