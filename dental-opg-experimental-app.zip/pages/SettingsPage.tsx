
import React, { useState } from 'react';
import Button from '../components/Button';
import Input from '../components/Input';

const SettingsPage: React.FC = () => {
  const [profileName, setProfileName] = useState('Dr. Dental');
  const [profileEmail, setProfileEmail] = useState('dentist@example.com');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [darkMode, setDarkMode] = useState(document.documentElement.classList.contains('dark'));

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate saving settings
    console.log('Settings saved:', { profileName, profileEmail, notificationsEnabled, darkMode });
    alert('Settings saved successfully (mock)!');
  };
  
  const toggleDarkMode = () => {
    const newDarkModeState = !darkMode;
    setDarkMode(newDarkModeState);
    if (newDarkModeState) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8 p-4">
      <h1 className="text-3xl font-semibold text-text-primary">Application Settings</h1>

      <form onSubmit={handleSaveSettings} className="space-y-6 bg-neutral-light p-6 rounded-lg shadow-lg">
        {/* Profile Settings */}
        <section>
          <h2 className="text-xl font-medium text-text-primary mb-3">Profile</h2>
          <Input 
            label="Display Name" 
            value={profileName} 
            onChange={(e) => setProfileName(e.target.value)} 
          />
          <Input 
            label="Email Address" 
            type="email"
            value={profileEmail} 
            onChange={(e) => setProfileEmail(e.target.value)} 
            disabled // Assuming email is not changeable or requires verification
          />
        </section>

        {/* Notification Settings */}
        <section>
          <h2 className="text-xl font-medium text-text-primary mb-3">Notifications</h2>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="notifications" 
              checked={notificationsEnabled}
              onChange={(e) => setNotificationsEnabled(e.target.checked)}
              className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
            />
            <label htmlFor="notifications" className="ml-2 block text-sm text-text-secondary">
              Enable email notifications for critical alerts
            </label>
          </div>
        </section>

        {/* Theme Settings */}
        <section>
          <h2 className="text-xl font-medium text-text-primary mb-3">Theme</h2>
           <div className="flex items-center">
             <button
                type="button"
                onClick={toggleDarkMode}
                className={`${
                  darkMode ? 'bg-primary' : 'bg-gray-200'
                } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2`}
                role="switch"
                aria-checked={darkMode}
              >
                <span className="sr-only">Use dark mode</span>
                <span
                  aria-hidden="true"
                  className={`${
                    darkMode ? 'translate-x-5' : 'translate-x-0'
                  } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                />
              </button>
            <label htmlFor="darkModeToggle" className="ml-2 block text-sm text-text-secondary">
              Enable Dark Mode
            </label>
          </div>
        </section>
        
        {/* API Key Info - as per instructions, do not allow user to input/manage */}
        <section>
          <h2 className="text-xl font-medium text-text-primary mb-3">API Keys</h2>
          <p className="text-sm text-text-secondary">
            Gemini API Key is configured via environment variable (<code className="bg-neutral-DEFAULT p-1 rounded text-xs">process.env.API_KEY</code>) and is not manageable here.
          </p>
        </section>


        <div className="pt-4 border-t border-neutral-DEFAULT">
          <Button type="submit" variant="primary">Save Settings</Button>
        </div>
      </form>
    </div>
  );
};

export default SettingsPage;
    