
import React, { useState } from 'react';
import Button from '../components/Button';
import Input from '../components/Input';
import { APP_NAME } from '../constants';

interface LoginPageProps {
  onLoginSuccess: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    if (email === 'dentist@example.com' && password === 'password') {
      onLoginSuccess();
    } else {
      setError('Invalid email or password. Use dentist@example.com and password.');
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-darker p-4">
      <div className="w-full max-w-md bg-neutral-dark p-8 rounded-xl shadow-2xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary">{APP_NAME}</h1>
          <p className="text-text-secondary mt-2">Dental Imaging, Perfected.</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            label="Email Address"
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
          />
          <Input
            label="Password"
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
          />
          {error && <p className="text-sm text-red-500 text-center">{error}</p>}
          <Button type="submit" variant="primary" size="lg" className="w-full" isLoading={isLoading}>
            {isLoading ? 'Logging In...' : 'Login'}
          </Button>
        </form>
        <p className="mt-6 text-center text-sm text-text-secondary">
          Demo: Use <code className="bg-neutral-light p-1 rounded">dentist@example.com</code> and <code className="bg-neutral-light p-1 rounded">password</code>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
    