
import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import PatientsPage from './pages/PatientsPage';
import ImageViewerPage from './pages/ImageViewerPage';
import UploadPage from './pages/UploadPage';
import SettingsPage from './pages/SettingsPage';
import Layout from './components/Layout';
import { APP_NAME } from './constants';

// Mock authentication
const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(localStorage.getItem('pano-pro-auth') === 'true');

  const login = () => {
    localStorage.setItem('pano-pro-auth', 'true');
    setIsAuthenticated(true);
  };

  const logout = () => {
    localStorage.removeItem('pano-pro-auth');
    setIsAuthenticated(false);
  };

  return { isAuthenticated, login, logout };
};


const App: React.FC = () => {
  const { isAuthenticated, login, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    document.title = `${APP_NAME} - ${location.pathname.split('/')[1] || 'Dashboard'}`;
  }, [location]);

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={login} />;
  }

  return (
    <Layout onLogout={logout}>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/patients" element={<PatientsPage />} />
        <Route path="/patients/:patientId/viewer" element={<ImageViewerPage />} />
        <Route path="/upload" element={<UploadPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
};

export default App;
    