
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_API_KEY_ENV_VAR, MODELS } from '../constants';
import { DentalAnalysisResponse } from "../types";

const apiKey = process.env[GEMINI_API_KEY_ENV_VAR];

if (!apiKey) {
  console.error("Gemini API key is not set. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "MISSING_API_KEY" });

/**
 * Generates content using the Gemini API.
 * This is a placeholder function to demonstrate API usage.
 */
export const generateGeneralText = async (prompt: string): Promise<string | null> => {
  if (!apiKey) {
    console.warn("Gemini API key not available. Skipping text generation.");
    return "Gemini API key not configured.";
  }
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODELS.text,
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error generating content with Gemini API:", error);
    return "Error generating content. Please check console for details.";
  }
};

/**
 * Analyzes an OPG image using Gemini API.
 */
export const analyzeOpgImage = async (base64ImageData: string, imageMimeType: string): Promise<DentalAnalysisResponse | null> => {
  if (!apiKey) {
    console.warn("Gemini API key not available. Skipping OPG analysis.");
    throw new Error("Gemini API key not configured.");
  }

  const detailedPrompt = `You are an expert dental radiologist AI assistant. Analyze the provided OPG (panoramic X-ray) image. Your analysis should be thorough and clinically relevant. Provide your response strictly in JSON format, without any markdown fences or additional text outside the JSON object. The JSON object must contain the following keys: "dentalFormula" (string, specify the notation used within this string, e.g., "Universal Numbering System: 1-32..."), "findings" (an array of strings, detailing specific observations like caries, bone loss, restorations, impacted teeth, anomalies, etc.), "diagnosisSummary" (a string providing a concise summary of the primary diagnoses), and "recommendedNextSteps" (an array of strings outlining actionable next steps for the patient or clinician).`;

  const imagePart = {
    inlineData: {
      mimeType: imageMimeType,
      data: base64ImageData,
    },
  };
  const textPart = {
    text: detailedPrompt
  };

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODELS.text, // Assuming gemini-2.5-flash-preview-04-17 can handle image + text.
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
      },
    });

    let jsonStr = response.text.trim();
    // Although responseMimeType: "application/json" is used,
    // robustly check for markdown fences just in case.
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    return JSON.parse(jsonStr) as DentalAnalysisResponse;

  } catch (error) {
    console.error("Error analyzing OPG image with Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to analyze OPG image: ${error.message}`);
    }
    throw new Error("An unknown error occurred during OPG image analysis.");
  }
};


// Placeholder for future image generation functionality
// ... (rest of the file remains the same for other functions)
